function sortArrayDescending(arr) {
    
    arr.sort(function(a, b) {
        
        return b - a;
    });
}


const numbers = [5, 2, 8, 1, 9, 3];
sortArrayDescending(numbers);


console.log("Sorted Array (Descending):", numbers);
